//
//  CDVCryptURLProtocol.h
//  CordovaLib
//
//  Created by tkyaji on 2015/07/15.
//
//

#import <Cordova/CDVURLProtocol.h>

@interface CDVCryptURLProtocol : CDVURLProtocol

@end
