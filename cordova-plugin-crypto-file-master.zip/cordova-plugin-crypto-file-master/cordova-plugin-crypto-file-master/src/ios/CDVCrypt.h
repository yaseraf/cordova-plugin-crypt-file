//
//  CDVCrypt.h
//  CordovaLib
//
//  Created by tkyaji on 2015/07/17.
//
//

#import <Cordova/CDVPlugin.h>

@interface CDVCrypt : CDVPlugin

- (void)pluginInitialize;

@end
